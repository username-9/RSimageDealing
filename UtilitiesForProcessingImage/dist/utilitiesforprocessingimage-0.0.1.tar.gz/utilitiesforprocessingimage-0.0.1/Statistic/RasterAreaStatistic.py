from osgeo import gdal
import numpy as np


def raster_area_statistic(raster_image):
    print("Make Sure The Coordination is Project Coordination")
    pass
