from setuptools import setup, find_packages

setup(
    name='UtilitiesForProcessingImage',
    version='0.0.1',
    packages=find_packages(),
    install_requires=['gdal',
                      'numpy'],
    author='username-9',
    author_email='escape_master@outlook.com',
    url='https://github.com/username-9/RSimageProcessing/UtilitiesForProcessingImage',
)